# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_payment
from . import payment_provider
from . import payment_transaction
from . import res_config_settings
from . import res_country
