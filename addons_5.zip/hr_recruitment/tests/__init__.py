# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_recruitment_process
from . import test_recruitment
from . import test_utm
from . import test_recruitment_interviewer
