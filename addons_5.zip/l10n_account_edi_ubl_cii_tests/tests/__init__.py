# -*- coding: utf-8 -*-

from . import test_xml_ubl_be
from . import test_xml_ubl_de
from . import test_xml_cii_fr
from . import test_xml_cii_us
from . import test_xml_ubl_nl
from . import test_xml_ubl_au
