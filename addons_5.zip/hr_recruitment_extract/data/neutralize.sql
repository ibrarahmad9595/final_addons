-- disable hr_recruitment_extract
DELETE FROM ir_config_parameter WHERE key = 'hr_recruitment_extract_endpoint';