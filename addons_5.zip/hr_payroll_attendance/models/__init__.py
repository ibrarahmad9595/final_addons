#-*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_contract
from . import hr_payslip_worked_days
from . import hr_payslip
