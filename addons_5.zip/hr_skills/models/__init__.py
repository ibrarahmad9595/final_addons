# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_employee
from . import hr_employee_public
from . import hr_resume_line
from . import hr_resume_line_type
from . import hr_skill
from . import hr_employee_skill
from . import hr_employee_skill_log
from . import hr_skill_level
from . import hr_skill_type
from . import res_users
