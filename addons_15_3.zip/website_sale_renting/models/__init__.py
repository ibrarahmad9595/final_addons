# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import product_pricelist
from . import product_product
from . import product_template
from . import res_company
from . import res_config_settings
from . import sale_order
from . import sale_order_line
from . import website
