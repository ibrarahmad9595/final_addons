-- disable website_sale_autocomplete
UPDATE website
SET google_places_api_key = 'dummy';