# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import loyalty_card
from . import loyalty_program
from . import loyalty_rule
from . import sale_order_line
from . import sale_order
