# -*- coding: utf-8 -*-

from . import product_product
from . import product_template
from . import sale_order
from . import slide_channel
from . import website
