# -*- coding: utf-8 -*-
{
    'name': "Account TaxCloud - Ecommerce",
    'category': 'Accounting/Accounting',
    'depends': ['sale_account_taxcloud', 'website_sale'],
    'data': ['views/templates.xml'],
    'auto_install': True,
    'license': 'OEEL-1',
}
