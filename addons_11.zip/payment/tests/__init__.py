# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import common
from . import http_common
from . import test_flows
from . import test_multicompany_flows
from . import test_payment_provider
from . import test_payment_token
from . import test_payment_transaction
