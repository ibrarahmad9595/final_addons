# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import onboarding_onboarding
from . import onboarding_step
from . import onboarding_progress
from . import onboarding_progress_step
