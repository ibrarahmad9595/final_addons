# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import chatbot_script_step
from . import crm_lead
from . import mail_channel
