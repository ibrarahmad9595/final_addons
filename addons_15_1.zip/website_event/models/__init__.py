# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import event_event
from . import event_registration
from . import event_tag_category
from . import event_type
from . import website
from . import website_event_menu
from . import website_menu
from . import website_snippet_filter
from . import website_visitor
