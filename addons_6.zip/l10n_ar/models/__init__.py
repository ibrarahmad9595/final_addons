# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import l10n_latam_identification_type
from . import l10n_ar_afip_responsibility_type
from . import account_journal
from . import account_tax_group
from . import account_fiscal_position
from . import account_fiscal_position_template
from . import l10n_latam_document_type
from . import res_partner
from . import res_country
from . import res_currency
from . import res_company
from . import res_partner_bank
from . import uom_uom
from . import account_chart_template
from . import account_move
from . import account_move_line
