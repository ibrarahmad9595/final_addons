# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import l10n_co_reports
from . import l10n_co_reports_fuente
from . import l10n_co_reports_ica
from . import l10n_co_reports_iva
