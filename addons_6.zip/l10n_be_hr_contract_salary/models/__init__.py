# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_contract
from . import hr_employee
from . import hr_payslip
from . import hr_job
from . import res_config_settings
from . import hr_contract_salary_resume
