# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import common
from . import test_payroll_allocating_paid_time_off
from . import test_payroll_credit_time_wizard
from . import test_payroll_right_to_legal_leaves
from . import test_eco_vouchers
