# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import base_document_layout
from . import account_move
from . import hr_timesheet
