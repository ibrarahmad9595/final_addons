# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import res_partner
from . import l10n_ec_sri_payment
from . import l10n_latam_document_type
from . import account_move
from . import account_tax
from . import account_tax_group
from . import res_company
from . import account_journal
