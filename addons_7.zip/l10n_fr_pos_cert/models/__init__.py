# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import account_bank_statement
from . import account_fiscal_position
from . import res_company
from . import pos
from . import account_closing
