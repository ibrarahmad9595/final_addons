# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import eta_activity_type
from . import uom_uom
from . import res_company
from . import res_partner
from . import account_move
from . import account_edi_format
from . import account_journal
from . import eta_thumb_drive
from . import res_currency_rate
from . import product_template
from . import res_config_settings
