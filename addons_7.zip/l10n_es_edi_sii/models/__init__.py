# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import account_edi_format
from . import account_move
from . import account_tax
from . import l10n_es_edi_certificate
from . import res_company
from . import res_config_settings
