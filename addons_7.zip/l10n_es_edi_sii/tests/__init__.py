# coding: utf-8

from . import test_edi_xml
from . import test_edi_web_services
