-- disable_l10n_es_edi_integration
UPDATE res_company
   SET l10n_es_edi_test_env = true;
