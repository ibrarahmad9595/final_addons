# -*- coding: utf-8 -*-

from . import hr_employee
from . import mrp_routing
from . import mrp_workorder
from . import mrp_workcenter
from . import quality
