# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


# from . import account_financial_html_report
from . import res_users
from . import account_financial_report
from . import hmrc_vat_obligation
from . import hmrc_service
