# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import link_tracker
from . import mail_render_mixin
from . import utm
