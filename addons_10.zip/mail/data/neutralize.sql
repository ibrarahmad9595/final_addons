-- deactivate mail template
UPDATE mail_template
   SET mail_server_id = NULL;
