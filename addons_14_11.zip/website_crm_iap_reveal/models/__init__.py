# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import crm_lead
from . import crm_reveal_rule
from . import crm_reveal_view
from . import ir_http
