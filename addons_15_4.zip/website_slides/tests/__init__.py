# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import common
from . import test_embed_detection
from . import test_gamification_karma
from . import test_security
from . import test_slide_channel
from . import test_slide_resource
from . import test_slide_slide
from . import test_statistics
from . import test_ui_wslides
