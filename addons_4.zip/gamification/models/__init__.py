# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import gamification_badge
from . import gamification_badge_user
from . import gamification_challenge
from . import gamification_challenge_line
from . import gamification_goal
from . import gamification_goal_definition
from . import gamification_karma_rank
from . import gamification_karma_tracking
from . import res_users
