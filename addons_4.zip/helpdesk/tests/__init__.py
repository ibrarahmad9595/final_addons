# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_helpdesk_flow
from . import test_helpdesk_portal
from . import test_helpdesk_sla
from . import test_helpdesk_rating
from . import test_ui
from . import test_doc_links
from . import test_helpdesk_team_privacy_visibility
