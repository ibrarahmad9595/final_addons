# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_move_reversal
from . import account_debit_note
