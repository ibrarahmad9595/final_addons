# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_payment_register
from . import l10n_latam_payment_mass_transfer
