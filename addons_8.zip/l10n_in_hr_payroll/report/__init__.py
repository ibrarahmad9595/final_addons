# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import report_payroll_advice
from . import report_hr_salary_employee_bymonth
from . import report_hr_yearly_salary_detail
