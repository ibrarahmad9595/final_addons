# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import common
from . import test_edi_export
from . import test_edi_import
from . import test_edi_reverse_charge
