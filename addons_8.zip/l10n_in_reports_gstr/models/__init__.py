# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import account_move
from . import gst_return_period
from . import res_company
from . import res_config_settings
