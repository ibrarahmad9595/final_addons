UPDATE res_company
   SET l10n_in_gstr_gst_production_env = false;
