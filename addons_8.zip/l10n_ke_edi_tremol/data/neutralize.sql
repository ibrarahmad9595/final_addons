-- neutralize connection to tremol controle unit
UPDATE res_company
SET l10n_ke_cu_proxy_address = '';