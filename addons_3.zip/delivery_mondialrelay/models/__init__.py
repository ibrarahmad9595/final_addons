# -*- coding: utf-8 -*-

from . import delivery_carrier
from . import res_partner
from . import sale_order
