# -*- coding: utf-8 -*-

from . import hr_applicant
from . import hr_job
from . import res_config_settings
from . import res_company
from . import workflow
