# -*- coding: utf-8 -*-

from . import test_documents
from . import test_documents_routes
from . import test_folders
from . import test_tags
from . import test_security
