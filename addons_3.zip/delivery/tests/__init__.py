# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing detailsself.

from . import test_delivery_cost, test_delivery_stock_move
from . import test_packing_delivery
from . import test_carrier_propagation
