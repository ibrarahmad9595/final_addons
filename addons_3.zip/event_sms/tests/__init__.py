# -*- coding: utf-8 -*-

from . import test_sms_schedule
