# -*- coding: utf-8 -*-

from . import account_move
from . import res_company
from . import res_config_settings
from . import workflow
from . import ir_attachment
