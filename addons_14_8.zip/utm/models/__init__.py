# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import utm_campaign
from . import utm_medium
from . import utm_mixin
from . import utm_source
from . import utm_stage
from . import utm_tag
from . import ir_http
