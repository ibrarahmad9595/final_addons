# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import common
from . import test_routes
from . import test_utm
from . import test_utm_consistency
from . import test_utm_security
