# -*- coding: utf-8 -*-
{
    'name': 'test mimetypes-guessing',
    'version': '0.1',
    'category': 'Hidden/Tests',
    'description': """A module to generate exceptions.""",
    'license': 'LGPL-3',
}
