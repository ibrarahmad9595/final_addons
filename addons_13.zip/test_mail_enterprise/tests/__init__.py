# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_activity
from . import test_activity_performance
from . import test_ocn_mobile
from . import test_sms_performance
