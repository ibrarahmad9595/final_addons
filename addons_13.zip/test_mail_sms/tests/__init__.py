# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_mail_thread_phone
from . import test_phone_blacklist
from . import test_sms_composer
from . import test_sms_management
from . import test_sms_performance
from . import test_sms_post
from . import test_sms_server_actions
from . import test_sms_sms
from . import test_sms_template
