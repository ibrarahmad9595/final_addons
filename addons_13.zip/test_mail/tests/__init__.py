# -*- coding: utf-8 -*-

from . import test_invite
from . import test_ir_actions
from . import test_mail_activity
from . import test_mail_composer
from . import test_mail_composer_mixin
from . import test_mail_followers
from . import test_mail_message
from . import test_mail_mail
from . import test_mail_gateway
from . import test_mail_multicompany
from . import test_mail_thread_internals
from . import test_mail_template
from . import test_mail_template_preview
from . import test_message_management
from . import test_message_post
from . import test_message_track
from . import test_performance
from . import test_ui
from . import test_mail_management
