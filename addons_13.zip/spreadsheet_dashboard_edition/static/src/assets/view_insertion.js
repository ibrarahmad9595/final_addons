/** @odoo-module **/

import { registry } from "@web/core/registry";

registry
    .category("spreadsheet_view_insertion_groups")
    .add("base.group_system", "base.group_system");
