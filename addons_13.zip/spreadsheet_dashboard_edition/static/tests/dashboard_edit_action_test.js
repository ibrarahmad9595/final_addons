/** @odoo-module **/

// TODO