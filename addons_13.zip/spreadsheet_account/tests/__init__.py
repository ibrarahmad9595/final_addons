# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_account_group
from . import test_debit_credit
from . import test_company_fiscal_year
