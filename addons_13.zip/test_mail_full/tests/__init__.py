# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_odoobot
from . import test_mail_performance
from . import test_mass_mailing
from . import test_portal
from . import test_rating
from . import test_res_users
