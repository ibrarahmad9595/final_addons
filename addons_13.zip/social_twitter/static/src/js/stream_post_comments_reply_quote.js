/** @odoo-module **/

import { StreamPostCommentsReplyTwitter } from './stream_post_comments_reply';

export class StreamPostCommentsReplyTwitterQuote extends StreamPostCommentsReplyTwitter {}

StreamPostCommentsReplyTwitterQuote.template = 'social_twitter.StreamPostCommentsReplyQuote';
