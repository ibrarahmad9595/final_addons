# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_blacklist
from . import test_blacklist_behavior
from . import test_blacklist_mixin
from . import test_link_tracker
from . import test_link_tracker_sms
from . import test_mailing
from . import test_mailing_server
from . import test_mailing_sms
from . import test_mailing_statistics
from . import test_mailing_statistics_sms
from . import test_mailing_test
from . import test_performance
