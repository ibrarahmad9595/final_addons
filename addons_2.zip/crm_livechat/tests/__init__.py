# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import chatbot_common
from . import test_chatbot_lead
from . import test_crm_lead
