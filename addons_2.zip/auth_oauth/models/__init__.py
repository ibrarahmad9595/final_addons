# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import auth_oauth
from . import res_config_settings
from . import ir_config_parameter
from . import res_users
