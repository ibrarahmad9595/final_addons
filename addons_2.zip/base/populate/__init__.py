from . import ir_filters
from . import res_partner
from . import res_company
from . import res_currency
from . import res_user
