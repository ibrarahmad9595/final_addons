# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import ir_http
from . import social_media
from . import social_account
from . import social_post
from . import social_post_template
from . import social_live_post
from . import website
from . import website_visitor
from . import website_visitor_push_subscription
from . import res_config_settings
from . import utm
