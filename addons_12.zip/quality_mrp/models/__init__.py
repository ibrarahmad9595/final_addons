# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import mrp_production
from . import quality
from . import stock_move
from . import stock_move_line
