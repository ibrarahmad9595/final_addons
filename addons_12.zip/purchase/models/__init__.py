# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_invoice
from . import analytic_account
from . import analytic_applicability
from . import purchase
from . import product
from . import res_company
from . import res_config_settings
from . import res_partner
from . import mail_compose_message
