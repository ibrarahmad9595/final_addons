# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_event_sale_with_product_configurator
from . import test_sale_product_matrix
from . import test_sale_product_configurator
