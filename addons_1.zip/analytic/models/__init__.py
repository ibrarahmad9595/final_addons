# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import analytic_plan
from . import analytic_account
from . import analytic_line
from . import analytic_mixin
from . import analytic_distribution_model
from . import res_config_settings
