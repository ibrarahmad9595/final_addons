# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_lu_reports_electronic
from . import test_lu_assets_report
from . import test_lu_sales_report
from . import test_lu_saft_report
