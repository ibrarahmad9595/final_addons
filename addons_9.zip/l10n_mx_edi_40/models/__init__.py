# -*- coding: utf-8 -*-

from . import account_edi_format
from . import account_move
from . import res_partner
