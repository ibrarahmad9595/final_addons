# -*- coding: utf-8 -*-

from . import account_general_ledger
from . import res_users
from . import ir_attachment
