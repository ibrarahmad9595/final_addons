Accounting chart for Netherlands
================================

This module is specially made to manage the accounting functionality
according to the Dutch best practice.

This module contains the Dutch Chart of Accounts and the VAT schema.
This schema is made for the most common Companies and therefore suitable
to be used for almost every Company.

The VAT accounts are linked promptly to generate the required reports. Examples
of this reports intercommunitaire transactions.

After installation of this module the configuration will be activated.
Select the Chart of Accounts named "Netherlands - Accounting".

Hereafter entering the name of the Company, total digits of Chart of Accounts,
Bank Account Number and the default Currency.

Note: total digits configured by default are 6.
