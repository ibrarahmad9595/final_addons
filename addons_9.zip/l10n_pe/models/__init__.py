# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import account_tax
from . import account_move
from . import l10n_latam_identification_type
from . import res_partner
from . import res_city_district
from . import res_city
from . import res_company
