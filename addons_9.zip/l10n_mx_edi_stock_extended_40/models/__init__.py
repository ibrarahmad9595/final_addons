# -*- coding: utf-8 -*-

from . import l10n_mx_edi_vehicle
from . import product_template
from . import stock_picking
